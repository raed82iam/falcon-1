# Stage 5 Architecture and Scope Proposal

**Status:** PROPOSED — OWNER REVIEW REQUIRED  
**Authority:** Stage 5 Planning and Design only  
**Implementation Authority:** NOT GRANTED  
**Repository Mutation:** NOT AUTHORIZED  
**Deployment / Runtime Activation:** NOT AUTHORIZED  
**Prepared:** 2026-08-06  

## 1. Mission

Stage 5 shall establish governed cross-boundary communication for Falcon Foundation and all admitted Falcon Applications.

The Stage 5 communication plane consists of:

```text
Application or Foundation Producer
        ↓
Canonical FIL Envelope
        ↓
Structural, schema, integrity, authority, and compatibility admission
        ↓
Service Bus routing and delivery control
        ↓
Authorized consumer
        ↓
Truthful response or event publication
```

## 2. Architectural principles

1. Application-neutral core.
2. Multi-Application by design.
3. Plug-and-Play through declared manifests and contracts.
4. No consumer-specific branching inside Foundation.
5. No hidden cross-boundary side channels.
6. Business payload opacity.
7. Explicit delivery semantics.
8. Fail-closed material validation.
9. Modular and replaceable implementations behind versioned contracts.
10. Easy improvement without silent production change.
11. Evidence-producing transport actions.
12. Safe attachment, upgrade, recovery, replacement, and detachment.

## 3. Canonical FIL message classes

- **Command:** requests an authorized state-changing action. It never proves completion.
- **Query:** requests information without changing governed state.
- **Response:** answers a Command or Query and binds to its correlation identity.
- **Event:** declares an accepted fact owned by an authorized fact owner.
- **Notice:** communicates non-command informational state.

## 4. Canonical envelope

The envelope shall preserve at least:

- message identity;
- kind and type;
- schema identity and version;
- producer identity;
- target or topic;
- purpose;
- classification;
- authority context where required;
- correlation and causation identity;
- fact owner for Events;
- created and expiry metadata;
- priority authority;
- protection profile and version;
- integrity scope;
- key reference and recipient binding;
- replay and idempotency policy;
- delivery-attempt identity;
- typed outcome support, including UNKNOWN;
- provenance reference;
- opaque payload.

## 5. Core components

### 5.1 Messaging primitives

Immutable canonical identifiers, outcomes, envelope types, provenance references, delivery identities, and validation results.

### 5.2 Schema registry

Registers exact schema identities, compatible versions, ownership, lifecycle, and rejection rules. Unknown or incompatible schemas fail closed.

### 5.3 Application Communication Manifest

Each admitted Application declares:

- schemas it owns or consumes;
- message types it may publish;
- commands and queries it may issue;
- subscriptions it requests;
- route purposes;
- protection profiles;
- ordering and delivery expectations;
- throughput and resource profile;
- retry, replay, and expiry expectations;
- upgrade and detachment behavior.

Manifest declaration does not grant authority. It creates an auditable request evaluated by admission and authority governance.

### 5.4 Service Bus admission

Admission validates structure, schema, producer, route, purpose, authority, integrity, protection, key context, recipient binding, replay policy, expiry, and compatibility before routing.

### 5.5 Dynamic routing

Routes are derived from admitted contracts and manifests, not hard-coded Application names. Routes remain immutable snapshots for a given accepted configuration identity.

### 5.6 Delivery control

Defines bounded retry, duplicate classification, prohibited replay, ordering scope, expiry, timeout, backpressure, flow control, priority governance, undeliverable containment, and evidence.

### 5.7 Event system

Publishes only facts accepted by the authorized fact owner. A successful Command response or Event may not exist before required state and evidence commitments succeed.

### 5.8 Safe attachment and detachment

Attachment activates only approved routes and subscriptions. Detachment stops new intake, drains or classifies in-flight work, removes routes and authority bindings, releases governed resources, preserves evidence, and proves no orphan bindings remain.

### 5.9 Cryptographic protection

Enforces minimum protection profiles, message integrity, confidentiality where required, authenticated producer and recipient context, key lifecycle status, recipient binding, and anti-downgrade behavior.

## 6. Modularity and evolvability

The architecture shall separate contracts from implementations. Validators, transports, routers, journals, schema stores, retry engines, cryptographic providers, and undeliverable stores shall be replaceable through governed interfaces and compatibility tests.

No implementation replacement may silently alter canonical semantics, authority, evidence, or accepted delivery guarantees.

## 7. Health and awareness boundary

- **Foundation Health:** observes technical health of Foundation services and hosted Applications.
- **FSA:** understands Foundation fitness, risks, gaps, and improvement only.
- **Application MSA:** understands the business and domain fitness of one Application.

Stage 5 transports their declared messages but does not merge or implement these responsibilities.

## 8. Explicit non-scope

Stage 5 shall not implement:

- trading, accounting, communication, or other business logic;
- FSATS activation;
- Paper, Tiny Live, or Live operation;
- FSA, MSA, LSA, or CSA behavior;
- Guardian mandate or crisis playbooks;
- full recovery governance;
- production deployment;
- cloud or broker connectivity;
- Stage 6 through Stage 9 behavior.

## 9. Completion condition

Stage 5 is complete only when all accepted work packages pass architecture, security, deterministic, mutation, multi-Application, safe-detachment, and VPL-004 verification, followed by independent review and Owner acceptance.
