# Stage 5 Traceability Matrix

**Status:** PROPOSED — OWNER REVIEW REQUIRED  
**Authority:** Stage 5 Planning and Design only  
**Implementation Authority:** NOT GRANTED  
**Repository Mutation:** NOT AUTHORIZED  
**Deployment / Runtime Activation:** NOT AUTHORIZED  
**Prepared:** 2026-08-06  

## Source-to-plan traceability

| Existing controlling subject | Stage 5 treatment |
|---|---|
| SYS-005 Service Bus | Preserved and expanded into bounded implementation work for admission, routing, delivery, isolation, and evidence |
| SYS-009 FIL | Preserved as canonical communication semantics; exact implementation requires version analysis |
| FIL-001 Foundation Message Schema v1.1 | Baseline input; no silent modification; successor only through governed versioning |
| VPL-004 Invalid FIL Message | Integrated and expanded with Plug-and-Play, multi-Application, security, and mutation scenarios |
| CON-023 Application Contract and Manifest | Baseline for Application Communication Manifest; any extension must be versioned |
| ADR-I015 Application and Awareness Alignment | Preserved: independent Plug-in Applications, Foundation neutrality, awareness separation |
| Stage 3 admission and dependency governance | Reused as prerequisites; no second admission or dependency owner |
| Stage 4 authority, lifecycle, State, Evidence, reconciliation | Reused as truth and continuation prerequisites; no duplicate owner |
| SEC-001 and cryptographic profiles | Enforced at message and route boundaries; no downgrade |
| FSATS V1.3 code-ready baseline | Downstream compatibility input only; no activation and no special Foundation semantics |

## Requirement-to-WP mapping

| Requirement area | Owning WP(s) |
|---|---|
| Message kinds, identity, UNKNOWN, provenance | WP-01 |
| Schema identity and compatibility | WP-02 |
| Application communication declarations | WP-03 |
| Structural and authority admission | WP-04 |
| Dynamic routing and isolation | WP-05 |
| Retry, replay, ordering, expiry, flow control | WP-06 |
| Event truth and journaling | WP-07 |
| Cryptographic protection | WP-08 |
| Attach, upgrade, replace, detach | WP-09 |
| Integrated VPL-004 and closure | WP-10 |

## Later-stage traceability

| Later stage | Stage 5 output consumed |
|---|---|
| Stage 6 | technical observations, freshness, provenance, contradictions, governed Health/awareness messaging |
| Stage 7 | protected restriction, revocation, and safe-state communication |
| Stage 8 | drain, replay, reattachment, failure containment, recovery communication |
| Stage 9 | complete communication evidence reconstruction and multi-Application conformance proof |
