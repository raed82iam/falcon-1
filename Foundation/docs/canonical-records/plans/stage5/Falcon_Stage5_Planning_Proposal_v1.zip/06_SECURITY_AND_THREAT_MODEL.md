# Stage 5 Security and Threat Model

**Status:** PROPOSED — OWNER REVIEW REQUIRED  
**Authority:** Stage 5 Planning and Design only  
**Implementation Authority:** NOT GRANTED  
**Repository Mutation:** NOT AUTHORIZED  
**Deployment / Runtime Activation:** NOT AUTHORIZED  
**Prepared:** 2026-08-06  

## Protected assets

- canonical message identity and payload integrity;
- producer and recipient identity;
- authority and delegation context;
- schema and compatibility truth;
- route and subscription configuration;
- classifications and protected content;
- event truth and accepted-fact lineage;
- keys, nonces, and cryptographic context;
- evidence and undeliverable records;
- isolation between Applications.

## Trust boundaries

1. Application to Foundation admission boundary.
2. Producer to Service Bus boundary.
3. Service Bus to consumer boundary.
4. Schema owner to registry boundary.
5. Transport provider boundary.
6. Event fact-owner boundary.
7. Storage and evidence boundary.
8. Attach, upgrade, and detach administrative boundary.

## Principal threats and required controls

| Threat | Required control |
|---|---|
| Producer impersonation | authenticated identity, signature/integrity validation, authority binding |
| Unauthorized publish/subscribe | manifest plus authority evaluation, default deny |
| Payload or envelope tampering | canonical integrity scope and cryptographic validation |
| Replay or duplicate execution | replay policy, idempotency identity, accepted-attempt ledger |
| Priority abuse | priority authority separated from producer claim |
| Schema confusion | exact schema identity, digest, owner, version and compatibility binding |
| Event forgery | fact-owner authority and state/evidence completion prerequisite |
| Cross-Application data leak | namespace isolation, recipient binding, classification enforcement |
| Downgrade | minimum profile enforcement and no plaintext fallback |
| Key misuse | key lifecycle status and purpose/recipient binding |
| Congestion attack | per-route and per-Application quotas, backpressure, bounded retry |
| Undeliverable secret leak | protected containment and redacted evidence |
| Hidden side channel | architecture tests and prohibited direct cross-boundary dependencies |
| Orphan access after removal | atomic detachment completion and independent orphan scan |
| Malicious provider replacement | exact implementation identity, compatibility verification, separate activation authority |

## Security failure posture

Material ambiguity, missing authority, integrity failure, incompatibility, unknown identity, wrong recipient, invalid key context, or required-protection unavailability shall fail closed.

Degradation may reduce availability but may not silently reduce identity, integrity, confidentiality, authority, evidence, or event-truth guarantees.

## Secret handling

Secrets and private keys shall not appear in source, ordinary configuration, FIL payloads, logs, evidence text, diagnostic output, test ZIPs, or undeliverable plaintext stores.

## Residual risk requiring later stages

- operational Guardian intervention belongs to Stage 7;
- full recovery and reintroduction governance belongs to Stage 8;
- independent full-system reconstruction belongs to Stage 9;
- production-scale distributed availability remains separately governed.
