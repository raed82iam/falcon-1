# VPL-004 Integrated Invalid FIL Message Verification Plan

**Status:** PROPOSED — OWNER REVIEW REQUIRED  
**Authority:** Stage 5 Planning and Design only  
**Implementation Authority:** NOT GRANTED  
**Repository Mutation:** NOT AUTHORIZED  
**Deployment / Runtime Activation:** NOT AUTHORIZED  
**Prepared:** 2026-08-06  

## Objective

Prove that invalid, unauthorized, incompatible, tampered, expired, replayed where prohibited, wrongly protected, or wrongly addressed FIL messages are rejected before any governed action, state change, or truthful-success publication.

## Positive scenarios

1. Valid Command admitted and completed through authorized lifecycle.
2. Valid Query and correlated Response.
3. Valid Event from authorized fact owner after accepted state and evidence completion.
4. Valid Notice.
5. Bounded retry preserving identity and lineage.
6. Authorized duplicate handled according to declared idempotency policy.
7. Two independent Applications exchange only declared messages.
8. Safe route drain and detachment.

## Negative structural and schema scenarios

- malformed serialization;
- missing required field;
- undeclared additional field where forbidden;
- unknown message kind;
- unknown type;
- unknown schema;
- unsupported schema version;
- schema digest mismatch;
- post-registration schema mutation;
- payload not conforming to bound schema.

## Negative identity and authority scenarios

- unknown producer;
- impersonated producer;
- unauthorized message type;
- unauthorized purpose;
- unauthorized target or topic;
- unauthorized publication;
- unauthorized subscription;
- revoked or expired delegation;
- priority self-elevation;
- fact-owner mismatch;
- authority-context mutation.

## Negative delivery scenarios

- expired message;
- prohibited replay;
- conflicting duplicate;
- delivery-attempt mutation;
- correlation mutation;
- causation mutation;
- wrong ordering key;
- unbounded retry attempt;
- route unavailable;
- consumer failure under load;
- undeliverable message disappearing without evidence.

## Negative security scenarios

- payload tampering;
- envelope tampering;
- classification mutation;
- wrong recipient;
- recipient-binding mutation;
- revoked key;
- expired key context;
- wrong protection profile;
- cryptographic downgrade;
- plaintext leakage into logs, errors, evidence, or undeliverable storage;
- nonce reuse where prohibited.

## Truth and state assertions

Every rejection scenario shall prove:

- no governed target action occurred;
- no authoritative state changed;
- no accepted fact was created;
- no success Response or Event was published;
- denial reason is exact and attributable;
- protected payload content is not leaked;
- unrelated routes and Applications remain unchanged.

## Plug-and-Play assertions

- Foundation works with zero Applications.
- two domain-distinct Applications coexist;
- one Application can be attached without source modification;
- one Application can fail without taking down the other;
- one Application can be upgraded and rolled back;
- one Application can be removed with no orphan binding;
- FSATS fixture receives no special Foundation behavior.

## Mutation testing

Mutate every load-bearing field independently: producer, target, topic, purpose, authority, kind, type, schema, version, payload digest, classification, protection, key, recipient, replay policy, expiry, message identity, delivery identity, correlation, causation, fact owner, route identity, subscription identity, event commit, and detachment completion.

## Determinism

The verifier shall produce the same decision identities, rejection reasons, accepted route identities, and evidence digests across clean reruns from the same inputs.
