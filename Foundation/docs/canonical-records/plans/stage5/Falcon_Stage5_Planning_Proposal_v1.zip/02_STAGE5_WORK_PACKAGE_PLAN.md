# Stage 5 Work-Package Plan

**Status:** PROPOSED — OWNER REVIEW REQUIRED  
**Authority:** Stage 5 Planning and Design only  
**Implementation Authority:** NOT GRANTED  
**Repository Mutation:** NOT AUTHORIZED  
**Deployment / Runtime Activation:** NOT AUTHORIZED  
**Prepared:** 2026-08-06  

## Proposed sequence

The work packages are deliberately small enough to review independently and ordered so later work cannot invent prerequisites retroactively.

### WP-01 — Canonical Messaging Primitives

Defines immutable identifiers, message kinds, typed outcomes including UNKNOWN, provenance, delivery identities, envelope contracts, and canonical serialization boundaries.

**Exit:** deterministic contract tests and no Application-specific semantics.

### WP-02 — Schema Registry and Compatibility

Defines schema ownership, registration, exact-version resolution, compatible-version rules, lifecycle, conflict rejection, canonical digest binding, and immutable snapshots.

**Exit:** unknown, conflicting, mutated, and incompatible schemas fail closed.

### WP-03 — Application Communication Manifest

Extends admitted Application metadata with declared publications, subscriptions, purposes, security profiles, ordering, throughput, replay, retry, expiry, upgrade, and detachment requirements.

**Exit:** declaration is immutable, attributable, and does not grant authority.

### WP-04 — FIL Validation and Message Admission

Implements structural, schema, classification, identity, authority-context, integrity, recipient, expiry, replay, and protection validation.

**Exit:** invalid messages are rejected before governed action.

### WP-05 — Service Bus Dynamic Routing and Isolation

Creates routes from admitted manifests and contracts, resolves capabilities, isolates namespaces and route resources, and prevents undeclared side channels.

**Exit:** two independent Applications can coexist without hard-coded Foundation branching.

### WP-06 — Delivery Semantics and Flow Control

Implements bounded retry, timeout, duplicate and replay classification, ordering scope, backpressure, priority governance, expiry, and undeliverable containment.

**Exit:** delivery guarantees are explicit, bounded, and evidence-backed.

### WP-07 — Event System and Truthful Publication

Implements fact-owner rules, correlation, causation, event journaling, projection support, and prevention of false-success publication.

**Exit:** no Event can claim success before required state and evidence completion.

### WP-08 — Cryptographic Message Protection

Implements protection-profile enforcement, integrity, confidentiality, authenticated context, recipient binding, key-status validation, and anti-downgrade behavior.

**Exit:** tampering, wrong recipient, revoked key, expired context, and downgrade attempts fail closed.

### WP-09 — Plug-and-Play Attachment, Upgrade, and Safe Detachment

Implements governed route attachment, subscription activation, version-compatible upgrade, route draining, resource release, authority detachment, and orphan detection.

**Exit:** an Application can be installed, attached, upgraded, stopped, replaced, and removed without Foundation redesign or unrelated-Application damage.

### WP-10 — Integrated VPL-004 and Multi-Application Closure

Runs valid and invalid message scenarios, two-Application coexistence, zero-Application Foundation validity, failure containment, replacement, removal, mutation tests, deterministic reruns, architecture and security tests, and independent review.

**Exit:** READY_FOR_STAGE5_OWNER_ACCEPTANCE_REVIEW.

## Stage gates

Each WP requires separate bounded implementation authority. No WP may borrow authority from this planning package or a later WP.

## Preservation rule

WP-01 through WP-10 shall preserve accepted Stage 0 through Stage 4 behavior. Any discovered need to modify accepted semantics becomes a separately governed change proposal, not an implicit Stage 5 edit.
